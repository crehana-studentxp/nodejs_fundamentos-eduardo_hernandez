const express = require('express');
const router = express.Router();
const {
  listaPelis,
  formularioPelis,
  agregaPeli,
  actualizaPeli,
} = require('../middlewares/pelis')

router.get('/', listaPelis);

router.post('/agregar', agregaPeli);

router.post('/actualizar', actualizaPeli);

router.get('/nueva', formularioPelis);

router.get('/:id', formularioPelis);

module.exports = router;

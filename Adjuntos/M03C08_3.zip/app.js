const {main} = require('./archivo');

main();

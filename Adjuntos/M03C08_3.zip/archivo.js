const fs = require('fs').promises;
const path = require('path');

const FILE_PATH = path.join(__dirname, 'archivo.json');

async function escribeArchivo(contenido) {
    console.log('Escribiendo archivo');

    try {
        await fs.writeFile(FILE_PATH, JSON.stringify(contenido, null, 4), 'utf8');
    }
    catch (error) {
        console.log(error);
    }
    console.log('Listo');
}

async function leeArchivo() {
    console.log('Leyendo archivo');
    let contenido = null;
    try {
        contenido = await fs.readFile(FILE_PATH, 'utf8');
    }
    catch(error) {
        console.log(error);
    }
    console.log('Listo');
    return JSON.parse(contenido);
}

async function main() {
    await escribeArchivo({ saludo: 'Hola mundo'});

    let contenido = await leeArchivo();
    contenido.saludo += ' desde un archivo modificado';
    await escribeArchivo(contenido);
    console.log(await leeArchivo());
}

module.exports = {
    main
}

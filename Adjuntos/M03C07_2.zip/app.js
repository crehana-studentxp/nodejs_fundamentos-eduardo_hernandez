const { pi, saludo} = require('./dummy');

console.log(pi);
saludo('Lalo');

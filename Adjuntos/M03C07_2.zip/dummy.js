module.exports = {
    pi: 3.14159,
    saludo: function(nombre) { console.log(`Hola ${nombre}`); },
}

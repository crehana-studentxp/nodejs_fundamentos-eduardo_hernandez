const fs = require('fs').promises;
const path = require('path');

const FILE_PATH = path.join(__dirname, 'archivo.txt');

async function escribeArchivo(contenido) {
    console.log('Escribiendo archivo');

    try {
        await fs.writeFile(FILE_PATH, contenido, 'utf8');
    }
    catch (error) {
        console.log(error);
    }
    console.log('Listo');
}

async function leeArchivo() {
    console.log('Leyendo archivo');
    let contenido = null;
    try {
        contenido = await fs.readFile(FILE_PATH, 'utf8');
    }
    catch(error) {
        console.log(error);
    }
    console.log('Listo');
    return contenido;
}

async function main() {
    await escribeArchivo('Hola mundo');
    console.log(await leeArchivo());
}

module.exports = {
    main
}

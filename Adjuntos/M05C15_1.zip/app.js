const express = require('express');
const path = require('path');

const app = express();

// configurar middlewares
app.use(express.static(path.join(__dirname, 'public')));

// definir rutas
app.get('/', (req, res, next) => {
    res.send(`
        <!doctype html>
        <html>
            <head>
                <title>Hola mundo</title>
            </head>
            <body>
                <h1>Hola mundo</h1>
            </body>
        </html>`
    );
});

module.exports = app;

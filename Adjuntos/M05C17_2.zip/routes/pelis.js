const express = require('express');
const router = express.Router();
const uuid = require('uuid');
const Pelis = require('../models/pelis');

router.get('/', (req, res, next) => res.render('pelis'));

router.post('/agregar', async (req, res, next) => {
  try {
    let peli = req.body;
    peli.id = uuid.v4();
    await Pelis.agregarPeli(peli);
  } catch (error) {
    next(error);
  }
  res.send('Peli agregada');
});

router.get('/nueva', (req, res, next) => res.render('pelis-form'));

module.exports = router;

const uuid = require('uuid');
const Pelis = require('../models/pelis')

// listado de pelis
async function listaPelis(req, res, next) {
    try {
        const pelis = await Pelis.listarPelis();
        res.render('pelis', { pelis });
    } catch (error) {
        next(error);
    }
}

// formulario para agregar o editar una peli
async function formularioPelis(req, res, next) {
    res.render('pelis-form');
}

// agregar una peli con los datos del formulario
async function agregaPeli(req, res, next) {
    try {
        let peli = req.body;
        peli.id = uuid.v4();
        await Pelis.agregarPeli(peli);
    } catch (error) {
        next(error);
    }
    res.send('Peli agregada');
}

module.exports = {
    listaPelis,
    formularioPelis,
    agregaPeli
};

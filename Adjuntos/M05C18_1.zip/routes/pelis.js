const express = require('express');
const router = express.Router();
const {
  listaPelis,
  formularioPelis,
  agregaPeli
} = require('../middlewares/pelis')

router.get('/', listaPelis);

router.post('/agregar', agregaPeli);

router.get('/nueva', formularioPelis);

module.exports = router;

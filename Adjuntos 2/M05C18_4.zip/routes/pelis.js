const express = require('express');
const router = express.Router();
const {
  listaPelis,
  formularioPelis,
  agregaPeli,
  actualizaPeli,
  eliminaPeli
} = require('../middlewares/pelis')

router.get('/', listaPelis);

router.post('/agregar', agregaPeli);

router.post('/actualizar', actualizaPeli);

router.post('/eliminar', eliminaPeli);

router.get('/nueva', formularioPelis);

router.get('/:id', formularioPelis);

module.exports = router;

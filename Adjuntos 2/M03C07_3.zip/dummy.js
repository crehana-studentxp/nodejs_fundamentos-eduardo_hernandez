const inicio = 'Hola';
const pi = 3.14159;

function saludo(nombre) {
    console.log(`${inicio} ${nombre}`);
}

module.exports = {
    pi,
    saludo,
}

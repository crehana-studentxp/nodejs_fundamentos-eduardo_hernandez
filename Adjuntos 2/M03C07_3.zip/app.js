const { pi, saludo, inicio} = require('./dummy');

console.log(pi);
saludo('Lalo');
console.log(inicio);

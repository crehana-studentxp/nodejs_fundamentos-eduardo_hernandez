const dummy = require('./dummy');

console.log(dummy.pi);
dummy.saludo('Lalo');

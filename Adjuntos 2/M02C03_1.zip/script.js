const dummy = {
    saludo: () => console.log('Hola mundo desde NodeJS'),
};

dummy.saludo();


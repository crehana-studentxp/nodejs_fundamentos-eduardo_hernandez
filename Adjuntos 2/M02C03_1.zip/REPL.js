1 + 1

const a = [1, 2, 3]

a

a.join('-')

a.map(item => item * 3)

function saludo(nombre) {
    console.log(`Hola, ${nombre}`);
}

saludo('Lalo')
